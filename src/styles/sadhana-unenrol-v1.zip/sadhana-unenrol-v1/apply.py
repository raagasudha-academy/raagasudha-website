#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path.cwd()
paths=['backend/src/academyOperations.ts','src/RegistrationModule.tsx','src/api/sadhanaClient.ts']
content={p:(root/p).read_text() if (root/p).is_file() else sys.exit('Missing '+p) for p in paths}
def change(p,a,b):
 s=content[p]
 if b in s:return
 if s.count(a)!=1:sys.exit('STOP: anchor mismatch in '+p+' ('+str(s.count(a))+'). No files written.')
 content[p]=s.replace(a,b)
p='backend/src/academyOperations.ts'
# The existing DELETE handler is created by the family-delete patch. Insert the enrolment case before family-only rejection.
needle="  if(kind!=='family'||!id)throw httpError(405,'Only family permanent deletion is supported.');"
block="""  if(kind==='enrolment'){
   if(!admin)throw httpError(403,'Only academy administrators can remove enrolments.');
   if(!id)throw httpError(400,'Enrolment ID is required.');
   const enrolment=await get(inst,'enrolment',id);
   if(!enrolment||enrolment.institution!==inst)throw httpError(404,'Enrolment not found in this academy.');
   if(body?.confirm!=='DELETE'||body?.expectedVersion!==enrolment.version)throw httpError(400,'Confirm DELETE with the current enrolment version.');
   // Do not remove an enrolment if any learning, attendance, RSVP or feedback depends on the student/class.
   // This is deliberately conservative: review ambiguous history rather than orphaning records.
   const linkedKinds=['attendance','practice','feedback','rsvp'] as const;
   for(const linkedKind of linkedKinds){
    const all=await rows(inst,linkedKind);
    if(all.some((r:any)=>r.studentId===enrolment.studentId &&
      (r.classId===enrolment.classId || !!r.sessionId)))
     throw httpError(409,'Student has learning, attendance or RSVP history. End the enrolment instead of permanently deleting it.');
   }
   const allOther=await rows(inst,'enrolment');
   if(allOther.some((r:any)=>r.id!==id&&r.studentId===enrolment.studentId&&r.classId===enrolment.classId))
    throw httpError(409,'Multiple enrolment records exist for this student and class; review before deletion.');
   try{await db.send(new TransactWriteCommand({TransactItems:[{Delete:{TableName:table(),Key:key(inst,'enrolment',id),ConditionExpression:'#v=:v AND institution=:i AND studentId=:s AND classId=:c',ExpressionAttributeNames:{'#v':'version'},ExpressionAttributeValues:{':v':enrolment.version,':i':inst,':s':enrolment.studentId,':c':enrolment.classId}}}]}));}
   catch(e:any){if(e.name==='TransactionCanceledException')throw httpError(409,'Enrolment changed. Refresh and retry.');throw e;}
   return {deleted:true,enrolmentId:id};
  }
"""
change(p,needle,block+needle)
p='src/api/sadhanaClient.ts'
needle="    updateOperation:(kind:'family'|'student'|'enrolment'|'attendance'|'practice'|'feedback'|'rsvp',institution:InstitutionId,id:string,data:ResourcePayload,expectedVersion:number)=>"
change(p,needle,"    deleteEnrolment:(institution:InstitutionId,id:string,expectedVersion:number)=>request<{deleted:boolean;enrolmentId:string}>('DELETE',`/operations/enrolment/${encodeURIComponent(id)}`,{institution,body:{confirm:'DELETE',expectedVersion}}),\n"+needle)
p='src/RegistrationModule.tsx'
change(p,"onEditEnrol, practiceLogs=[] }: any)","onEditEnrol, onRemoveEnrol, practiceLogs=[] }: any)")
change(p,'<button className="reg-secondary" onClick={()=>onEditEnrol(e)}>Edit dates</button></div>', '<button className="reg-secondary" onClick={()=>onEditEnrol(e)}>Edit dates</button><button type="button" className="reg-danger" onClick={()=>onRemoveEnrol(e)}>Remove enrolment</button></div>')
change(p,"  const [editEnrol,setEditEnrol]=useState(null);","  const [editEnrol,setEditEnrol]=useState(null);\n  const [removeEnrol,setRemoveEnrol]=useState<any>(null);\n  const [removePhrase,setRemovePhrase]=useState('');")
needle="  const convertIndividual=(values:any)=>"
block="""  const confirmRemoveEnrol=()=>{
    if(!removeEnrol||removePhrase!=='DELETE'||writing)return;
    const target=removeEnrol;
    void persist(async()=>{await operationsApi.deleteEnrolment(workspace,target.id,target.version);},
      'Enrolment permanently removed. Student and family records were preserved.',
      ()=>{setRemoveEnrol(null);setRemovePhrase('');});
  };
"""
change(p,needle,block+needle)
change(p,"onEditEnrol={e=>{setEditEnrol(e);setDialog('edit-enrol');}} practiceLogs={practiceLogs}","onEditEnrol={e=>{setEditEnrol(e);setDialog('edit-enrol');}} onRemoveEnrol={e=>{setRemoveEnrol(e);setRemovePhrase('');}} practiceLogs={practiceLogs}")
needle="    {archiveTarget&&<Modal"
block="""    {removeEnrol&&<Modal title="Permanently remove enrolment?" subtitle="Only unused test enrolments can be deleted. Learning history will block this operation." onClose={()=>{if(!writing){setRemoveEnrol(null);setRemovePhrase('');}}}><div className="reg-form"><p>This removes only the selected class enrolment. It does not delete the student, family, or reset roll numbers.</p><Field label="Type DELETE to confirm"><input autoComplete="off" value={removePhrase} onChange={e=>setRemovePhrase(e.target.value)} placeholder="DELETE"/></Field><div className="reg-modal-actions"><button type="button" className="reg-secondary" onClick={()=>{setRemoveEnrol(null);setRemovePhrase('');}}>Cancel</button><button type="button" className="reg-danger" disabled={writing||removePhrase!=='DELETE'} onClick={confirmRemoveEnrol}>Remove enrolment permanently</button></div></div></Modal>}
"""
change(p,needle,block+needle)
for name,data in content.items():(root/name).write_text(data)
print('Patched 3 files. No AWS changes. Run tests, review diff, then deploy frontend and backend.')
