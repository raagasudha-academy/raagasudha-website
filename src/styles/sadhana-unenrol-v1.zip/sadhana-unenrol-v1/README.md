# Sadhana — Permanent test enrolment removal (local patch)

Run from `~/Dev/sadhana` after installing family-delete-v1:

```bash
python3 ~/Downloads/sadhana-unenrol-v1/apply.py
npm run verify
npm run test:e2e
(cd backend && npm run check)
git diff --check
```

Administrator > Student > Classes: Remove enrolment. Requires typing DELETE. Backend refuses deletion when learning, attendance, feedback or RSVP records are detected. For ordinary withdrawal with history, use Edit dates. Family deletion still refuses other linked records. This patch does not delete data, deploy to AWS, reset counters, or relax those safeguards.

**Warning:** This implementation deliberately conservatively blocks some historical data, especially any RSVP/attendance for the student. Test and inspect the diff before deploying. No cascade deletion is implemented.
